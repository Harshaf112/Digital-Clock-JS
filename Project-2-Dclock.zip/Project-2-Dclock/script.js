function updateTime() {
    const options = {
      timeZone: 'Asia/Kolkata', // Time zone for Lucknow (IST)
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    };
  
    const time = new Date().toLocaleString('en-US', options);
    document.getElementById('time').textContent = time;
  }
  
  // Update the time every second
  setInterval(updateTime, 1000);
  
  // Set the initial time when the page loads
  updateTime();
  
 